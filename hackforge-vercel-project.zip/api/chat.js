const MAX_MESSAGE_LENGTH = 1200;
const MAX_MESSAGES = 12;
const rateBuckets = new Map();
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 20;

const instituteContext = `You are ForgeBot, the official AI assistant for HackForge Institute.
Answer clearly, briefly, and helpfully about HackForge Institute only.
Known information:
- HackForge teaches live, practical cybersecurity education for beginners and aspiring security professionals.
- Cybersecurity & Ethical Hacking Master Program: USD $57.66 one-time payment, lifetime access, no recurring fees.
- Its modules include Introduction to Cybersecurity; Lab Setup & Virtualization; Linux Fundamentals & Kali Linux; Networking Fundamentals; Wireless Network Security; System Security & System Takeover; Client-Side Security; OSINT & Human Intelligence Gathering; Social Engineering; WhatsApp Security & Messaging Security; Android Security & Android Hacking; Remote Access & Lab Networking; Post-Exploitation Concepts & Practical; Defence Hardening & Firewall Security.
- Advanced Android Hacking Master Program: USD $50.40 one-time payment, lifetime access, no recurring fees. It is for learners who already understand Android security basics.
- Advanced Android modules include Android Security Fundamentals review; Android Lab Setup; Android Architecture & Application Internals; Android Penetration Testing Methodology; Static & Dynamic Analysis; Advanced Obfuscation & Deobfuscation Techniques; Advanced Obfuscation Methods; Bypassing Root Detection & Anti-Debugging; Runtime Instrumentation & Dynamic Hooking; Access on Local Network & Over the Internet; Modern Android Exploitation Techniques; Latest Industry Tools for Android Security; Real-World Android Hacking Labs & Case Studies.
- Enrollment and payment are handled through WhatsApp: +92 319 5661775.
- Email: hackforgeinstitute@gmail.com.
- Explain that training must be used legally and ethically. Do not provide instructions for wrongdoing, credential theft, malware deployment, unauthorized access, or evasion.
- If asked about something not related to HackForge, say you can help with HackForge-related questions or direct them to WhatsApp/email.
Do not invent schedules, certificates, refunds, guarantees, or policies not listed above.`;

function getClientKey(req) {
  const forwarded = req.headers['x-forwarded-for'];
  return (forwarded ? forwarded.split(',')[0] : req.socket?.remoteAddress || 'unknown').trim();
}

function allowedRequest(key) {
  const now = Date.now();
  const old = rateBuckets.get(key) || { start: now, count: 0 };
  if (now - old.start >= WINDOW_MS) {
    old.start = now;
    old.count = 0;
  }
  old.count += 1;
  rateBuckets.set(key, old);
  if (rateBuckets.size > 5000) {
    for (const [k, v] of rateBuckets) if (now - v.start > WINDOW_MS) rateBuckets.delete(k);
  }
  return old.count <= MAX_REQUESTS_PER_WINDOW;
}

function cleanMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages.slice(-MAX_MESSAGES).filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .map(m => ({ role: m.role, content: m.content.slice(0, MAX_MESSAGE_LENGTH) }));
}

function fallbackAnswer(message) {
  const q = message.toLowerCase();
  if (q.includes('57.66') || q.includes('ethical hacking') || q.includes('cybersecurity master')) return 'The Cybersecurity & Ethical Hacking Master Program costs $57.66 as a one-time payment and includes lifetime access with no recurring monthly fees. You can enroll through WhatsApp at +92 319 5661775.';
  if (q.includes('50.40') || q.includes('android')) return 'The Advanced Android Hacking Master Program costs $50.40 as a one-time payment, includes lifetime access, and is intended for learners who already know the basics of Android security. Enroll through WhatsApp at +92 319 5661775.';
  if (q.includes('contact') || q.includes('whatsapp') || q.includes('enroll') || q.includes('pay')) return 'You can contact HackForge Institute on WhatsApp at +92 319 5661775 or email hackforgeinstitute@gmail.com. Enrollment and payment are handled through WhatsApp.';
  if (q.includes('module') || q.includes('course')) return 'HackForge offers a Cybersecurity & Ethical Hacking Master Program and an Advanced Android Hacking Master Program. You can view the complete module lists on this website or ask me about a specific program.';
  return 'I can help with HackForge Institute courses, modules, prices, and enrollment. For a direct response from the team, contact WhatsApp at +92 319 5661775 or email hackforgeinstitute@gmail.com.';
}

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (!allowedRequest(getClientKey(req))) return res.status(429).json({ error: 'Too many requests. Please try again shortly.' });

  const body = req.body || {};
  const messages = cleanMessages(body.messages);
  if (!messages.length || messages[messages.length - 1].role !== 'user') return res.status(400).json({ error: 'A user message is required.' });

  const latest = messages[messages.length - 1].content;
  if (latest.length > MAX_MESSAGE_LENGTH) return res.status(400).json({ error: 'Message is too long.' });

  if (!process.env.OPENAI_API_KEY) return res.status(200).json({ answer: fallbackAnswer(latest), mode: 'faq-fallback' });

  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        instructions: instituteContext,
        input: messages,
        max_output_tokens: 450,
        temperature: 0.2,
      }),
    });
    if (!response.ok) return res.status(502).json({ error: 'The AI service is temporarily unavailable.' });
    const data = await response.json();
    const answer = data.output_text || 'I could not generate a response right now. Please contact HackForge on WhatsApp.';
    return res.status(200).json({ answer, mode: 'ai' });
  } catch (error) {
    return res.status(500).json({ error: 'The assistant is temporarily unavailable.' });
  }
};
